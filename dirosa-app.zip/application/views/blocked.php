<?php $this->load->view('admin/inc/header') ?>

<body>

    <div class="container" style="margin-top: 50px; ">
        <div class="row">
            <!-- Form with validation -->
            <div class="col s12 m6 offset-m3">
                <div class="card-panel">
                    <h1 class="header2 center">403</h1>
                    <h4 class="header2 center">Access Denied!</h4>
                </div>
            </div>
        </div>

    </div>

    <?php $this->load->view('admin/inc/footer') ?>