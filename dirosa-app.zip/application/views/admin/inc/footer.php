<!-- ================================================
    Scripts
    ================================================ -->
<!-- jQuery Library -->
<script type="text/javascript" src="<?= base_url('assets/admin/') ?>vendors/jquery-3.2.1.min.js"></script>
<!--materialize js-->
<script type="text/javascript" src="<?= base_url('assets/admin/') ?>js/materialize.min.js"></script>
<!--scrollbar-->
<script type="text/javascript" src="<?= base_url('assets/admin/') ?>vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<!--custom-script.js - Add your own theme custom JS-->
<script type="text/javascript" src="<?= base_url('assets/admin/') ?>js/custom-script.js"></script>

<!--plugins.js - Some Specific JS codes for Plugin Settings-->
<script type="text/javascript" src="<?= base_url('assets/admin/') ?>js/plugins.js"></script>

<script src="<?= base_url('') ?>js/sw.js"></script>
</body>

</html>